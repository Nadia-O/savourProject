from django.apps import AppConfig


class SavourAppConfig(AppConfig):
    name = 'savour_app'
